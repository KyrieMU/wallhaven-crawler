# Wallhaven Crawler

一个强大的 Wallhaven 网站爬虫库，可以轻松下载高质量壁纸。

## 安装

```bash
pip install wallhaven-crawler